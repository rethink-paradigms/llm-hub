"""SP4 - Catalog View: Error definitions."""


class CatalogViewError(Exception):
    """Raised when catalog loading fails."""
    pass
