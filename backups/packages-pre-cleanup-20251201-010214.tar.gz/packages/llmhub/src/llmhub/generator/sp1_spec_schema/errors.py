"""SP1 - Spec Schema: Error definitions."""


class SpecSchemaError(Exception):
    """Raised when spec parsing or validation fails."""
    pass
