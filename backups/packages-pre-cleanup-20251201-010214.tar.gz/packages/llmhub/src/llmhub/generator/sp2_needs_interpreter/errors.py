"""SP2 - Needs Interpreter: Error definitions."""


class InterpreterError(Exception):
    """Raised when LLM interpretation fails."""
    pass
