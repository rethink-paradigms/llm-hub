"""SP3 - Needs Schema: Error definitions."""


class NeedsSchemaError(Exception):
    """Raised when RoleNeed parsing or validation fails."""
    pass
